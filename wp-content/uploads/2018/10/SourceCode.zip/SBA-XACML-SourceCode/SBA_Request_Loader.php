<?php

/**
 * XA request loader
*/

// if not loaded then load
if (!function_exists('file_open'))
{
     require_once('File_Open.php');
}

require_once('File_Open.php');
// XA request file name
if (empty($_Request_file_name))
{
	$_Request_file_name = 'SBA\SBA_request.txt';
}

//
if (!function_exists('load'))
{
     require_once('load.php');
}

//lets work on the request here
$Request_lines = file_open($_Request_file_name);
$Request_stack = load($Request_lines);

foreach($Request_lines as $key0 => $value)
{
	// remove {} from start and end of string
	$Request_stack[$key0][1]= substr($Request_stack[$key0][1],1,-1);

	// explode values based on ','
	$Request_stack[$key0][1] = explode(',',$Request_stack[$key0][1]);

	// remove {} from start and end of string
	$Request_stack[$key0][2]= substr($Request_stack[$key0][2],1,-1);

	// explode values based on ','
	$Request_stack[$key0][2] = explode(',',$Request_stack[$key0][2]);

	// remove {} from start and end of string
	$Request_stack[$key0][3]= substr($Request_stack[$key0][3],1,-1);

	// explode values based on ','
	$Request_stack[$key0][3] = explode(',',$Request_stack[$key0][3]);

}
?>