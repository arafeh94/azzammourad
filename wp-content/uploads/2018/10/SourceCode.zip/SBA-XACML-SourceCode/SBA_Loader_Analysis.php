<?php

/**
 * SBA Based Policy Loader
*/

// XA base policy file name
$_Policy_file_name = 'SBA\SBA_Policy.txt';

// Require file_open to use for opening the input file
require_once('File_Open.php');

// Parse subsets
function parse_subsets ($string)
{
	// get a string count
	$line_count = strlen($string);
	$loop_counter = 0;
	$count_opened_curly = 0;
	$count_closed_curly = 0;
	$hold_string = '';
	$index = 0;
	$stack = array();
	while ($loop_counter < $line_count )
	{
		$char = substr($string,$loop_counter,1);
		if( $char == '}')
		{
			$count_closed_curly++;
			$hold_string = $hold_string.$char;
			if ($count_opened_curly == $count_closed_curly)
			{
				$stack[$index] = $hold_string;
				$index++;
				$count_opened_curly = 0;
				$count_closed_curly = 0;
				$hold_string = '';
			}

		}
		else
		{
			if( $char == '{')
			{
				$count_opened_curly++;
			}

			$hold_string = $hold_string.$char;
			// if we get a comma as the first character then we can remove
			if ($hold_string == ',')
			{
				$hold_string = '';
			}
		}

		$loop_counter++;
	}
	return $stack;
}

function Target ($string)
{

	// remove {} from start and end
	$string = substr ($string,1,-1);
	// explode values based on ','
	$_array = explode(',',$string);
	return $_array;
}

// Obligation parser function
function Obligation ($obl)
{
	$stack = parse_subsets($obl);
	$i = 0;
	while (isset($stack[$i]))
	{
		$stack[$i] = explode (',{', $stack[$i]);
		$j = 0;
		while (isset($stack[$i][$j]))
		{
			$stack[$i][$j] = str_replace ('{','',$stack[$i][$j]);
			$stack[$i][$j] = str_replace ('}','',$stack[$i][$j]);
			$stack[$i][$j] = explode (',', $stack[$i][$j]);
			$j++;
		}
		$i++;
	}
	return $stack;
}

// Rule condition parser function
function Rule_condition ($condition)
{
	//display($condition);

	$condition = str_replace( ' ','',$condition);
	//$condition = substr($condition,1);
	//$condition = substr($condition,1,-1);
	$condition = explode(',{',$condition);
	//display($condition);
	$_function_index = 0;
	while (isset($condition[$_function_index]))
	{
		//$condition[$_function_index] = explode(',',$condition[$_function_index]);
		$condition[$_function_index] = str_replace( '}','',$condition[$_function_index]);
		$condition[$_function_index] = str_replace( '{','',$condition[$_function_index]);
		$_function_index++;
	}
	//display($condition);
	return $condition;
}


// load the policy into the main array
function load ($lines)
{
	$stack = array();
	foreach($lines as $key0 => $value)
	{
		// explode string to get whether PS,P or R
		$value = str_replace(' ','', $value);
		$explode_line[$key0] = explode('<',$value);
		//get a string count
		$line_count = strlen($explode_line[$key0][1]);
		$loop_counter = 0;
		$count_opened_curly = 0;
		$count_closed_curly = 0;
		$hold_string = '';

		// initialize $stack with policy/rule name
		$stack[$key0] = array($explode_line[$key0][0]);

		while ($loop_counter < $line_count )
		{
			$char = substr($explode_line[$key0][1],$loop_counter,1);
			if( $char == '}')
			{
				$count_closed_curly++;
				$hold_string = $hold_string.$char;
				if ($count_opened_curly == $count_closed_curly)
				{
					array_push($stack[$key0],$hold_string);
					$count_opened_curly = 0;
					$count_closed_curly = 0;
					$hold_string = '';
				}

			}
			else
			{
				if( $char == '{')
				{
					$count_opened_curly++;
				}

				$hold_string = $hold_string.$char;
				// if we get a comma as the first character then we can remove
				if ($hold_string == ',')
				{
					$hold_string = '';
				}
			}

			$loop_counter++;
		}
	}
	return $stack;
}

$lines = file_open($_Policy_file_name);
$stack = load($lines);

// Reformat Array
$i = 0;
while ($i < count($stack))
{
	$_array = explode(',{',$stack[$i][1]);
	$stack[$i][0] = substr ($stack[$i][0],0,-1);
	if (substr ($stack[$i][0],0,2) == "PS" || substr ($stack[$i][0],0,2) == "P:" )
	{
		$_array[1] = '{'.$_array[1];
		$stack[$i][0] = $stack[$i][0].$_array[0].'::=';
		$stack[$i][1] = $_array[1];
	}
	if (substr ($stack[$i][0],0,2) == "R:")
	{
		$_array1 = explode(',{',$stack[$i][1],2);
		$_array1[1] = '{'.$_array1[1];
		$stack[$i][0] = $stack[$i][0].$_array1[0].'::=';
		$stack[$i][1] = $_array1[1];
	}
	$i++;
}

foreach($lines as $key0 => $value)
{
	// exploding PolicySet type PS into thier own arrays
	if (substr ($stack[$key0][0],0,2) == "PS")
	{
		// remove {} from start and end of string
		$stack[$key0][1]= substr($stack[$key0][1],1,-1);

		// explode values based on ','
		$stack[$key0][1] = explode(',',$stack[$key0][1]);
		// remove {} from start and end of string
		$stack[$key0][2]= substr($stack[$key0][2],1,-1);

		// explode values based on '>'
		$stack[$key0][2] = explode('>',$stack[$key0][2]);

		// remove {} from start and end of string
		$stack[$key0][3]= substr($stack[$key0][3],1,-1);

		// Obligation index = 5 at the policySet
		$_index = 5;

		// remove {} from start and end
		if (isset ($stack[$key0][$_index]))
		{
			$stack[$key0][$_index]= substr($stack[$key0][$_index],1,-1);

			// call obligation function
			$stack[$key0][$_index] = obligation($stack[$key0][$_index]);
		}
	}


	// exploding Policies type P: into thier own arrays
	if (substr ($stack[$key0][0],0,2) == "P:")
	{
		// remove {} from start and end of string
		$stack[$key0][1]= substr($stack[$key0][1],1,-1);

		// explode values based on ','
		$stack[$key0][1] = explode(',',$stack[$key0][1]);

		// remove {} from start and end of string
		$stack[$key0][2]= substr($stack[$key0][2],1,-1);

		// explode values based on '>'
		$stack[$key0][2] = explode('>',$stack[$key0][2]);

		// remove {} from start and end of string
		$stack[$key0][3]= substr($stack[$key0][3],1,-1);

		// Obligation index = 4 at the policy
		$_index = 4;

		//echo $stack[$key0][$_index]."<br>";
		// remove {} from start and end

		if (isset ($stack[$key0][$_index]))
		{
			$stack[$key0][$_index]= substr($stack[$key0][$_index],1,-1);

			// call obligation function
			$stack[$key0][$_index] = obligation($stack[$key0][$_index]);
		}

	}

	// Parse target and explode each subset into an array by itself
	if (substr ($stack[$key0][0],0,2) == "PS" || "P:" || "R:")
	{
			// if Policy Set
			if (substr ($stack[$key0][0],0,2) == "PS")
			{
				$_index = 6;
			}

			// if Policy
			if (substr ($stack[$key0][0],0,2) == "P:")
			{
				// was 6
				$_index = 5;
			}

			// If rule
			if (substr ($stack[$key0][0],0,2) == "R:")
			{
				$_index = 2;
			}
			// Parse target and explode each subset into an array
			// remove {} from start and end

			$stack[$key0][$_index]= substr($stack[$key0][$_index],1,-1);
			// explode into subjects, resources and actions by calling parse_subsets function
			$stack[$key0][$_index] = parse_subsets ($stack[$key0][$_index]);

			// loop and parse Subject, Resources and Actions in target
			for ($target_loop = 0; $target_loop <= 2; $target_loop++)
			{
				// call target function for Subjects at 0, Resources at 1 and Actions at 2
				$stack[$key0][$_index][$target_loop] = target($stack[$key0][$_index][$target_loop]);
				//var_dump ($stack[$key0][$_index][$target_loop]);
			}
	}

	// if the line is a rule line
	if (substr ($stack[$key0][0],0,2) == "R:")
	{
		// parse the conditions if any exist
		if (isset ($stack[$key0][0]))
		{
			// call rule condition function
			$stack[$key0][1] = Rule_condition ($stack[$key0][1]);
		}
		$stack[$key0][3] = substr($stack[$key0][3],1,-1);
	}

}

?>