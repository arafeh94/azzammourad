Please Note that this program is a prototype for research and WITHOUT ANY WARRANTY. We are not responsible for any damages, loss, etc. 

1. Visit http://www.easyphp.org/easyphp-devserver.php and Install EASYPHP DEVSERVER 14.1 VC9.

2. Create a folder in the www directory on your machine and extract the files in it. 

3. For instruction manual, check User-instruction.txt