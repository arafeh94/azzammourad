<?php

/**
 * XA_request Converts XACML request to SBA.
*/

require_once("xml2array.php");

// Converted SBA file output - specificy the output here
$output_file=fopen('SBA\SBA_request.txt',"w") or exit("Unable to open file for writting!");

function array_values_recursive_function( $array )
{
    $array = array_values( $array );
    for ( $i = 0, $n = count( $array ); $i < $n; $i++ )
    {
        $element = $array[$i];
        if ( is_array( $element ) )
        {
            $array[$i] = array_values_recursive_function( $element );
        }
    }
    return $array;
}

// Input file to read the xacml file
$contents = file_get_contents('XACML\request.xml');
$result = xml2array($contents);

while (key($result))
{
	// children level 1
	if (isset($result[key($result)]))
	{
		while (key($result[key($result)]))
		{
			if (key($result[key($result)]) == 'Subject')
			{
				$Subject = $result[key($result)]['Subject'];
			}
			if (key($result[key($result)]) == 'Resource')
			{
				$Resource = $result[key($result)]['Resource'];
			}
			if (key($result[key($result)]) == 'Action')
			{
				$Action = $result[key($result)]['Action'];

			}

			next ($result[key($result)]);
		}
	}
	next ($result);
}

// Parse Subjects
if (isset ($Subject))
{

	if(isset ($Subject['Attribute']))
	{
		if(isset ($Subject['Attribute'][0]))
		{
			$number_of_Subjects = count ($Subject['Attribute']);
			for ($count = 0;$count < $number_of_Subjects; $count++)
			{
				if (!empty ($Subject['Attribute'][$count]['AttributeValue']['value']))
				{
					if ($count == 0)
					{
						$_result[0] = $Subject['Attribute'][$count]['AttributeValue']['value'];
					}
					else
					{
						$_result[0] = $_result[0].",".$Subject['Attribute'][$count]['AttributeValue']['value'];
					}
				}
			}
		}
		else
		{
			// just one resource attr attrva value
			if (isset ($Subject['Attribute']['AttributeValue']['value']))
			{
				$_result[0] = $Subject['Attribute']['AttributeValue']['value'];
			}
			else
			{
				$_result[0] = "";
			}
		}
	}
}

// parse request resources
if (isset ($Resource))
{
	if(isset ($Resource['Attribute']))
	{
		if(isset ($Resource['Attribute'][0]))
		{
			$number_of_Resources = count ($Resource['Attribute']);
			for ($count = 0;$count < $number_of_Resources; $count++)
			{
				if (!empty ($Resource['Attribute'][$count]['AttributeValue']['value']))
				{
					if ($count == 0)
					{
						$_result[1] = $Resource['Attribute'][$count]['AttributeValue']['value'];
					}
					else
					{
						$_result[1] = $_result[1].",".$Resource['Attribute'][$count]['AttributeValue']['value'];
					}
				}
			}
		}
		else
		{
			// just one resource attr attrva value
			if (isset ($Resource['Attribute']['AttributeValue']['value']))
			{
				$_result[1] = $Resource['Attribute']['AttributeValue']['value'];
			}
			else
			{
				$_result[1] = "";
			}
		}
	}
}

if (isset ($Action))
{
	if(isset ($Action['Attribute']))
	{
		if(isset ($Action['Attribute'][0]))
		{
			$number_of_Actions = count ($Action['Attribute']);
			for ($count = 0;$count < $number_of_Actions; $count++)
			{
				if (!empty ($Action['Attribute'][$count]['AttributeValue']['value']))
				{
					if ($count == 0)
					{
						$_result[2] = $Action['Attribute'][$count]['AttributeValue']['value'];
					}
					else
					{
						$_result[2] = $_result[2].",".$Action['Attribute'][$count]['AttributeValue']['value'];
					}
				}
			}
		}
		else
		{
			// just one resource attr attrva value
			if (isset ($Action['Attribute']['AttributeValue']['value']))
			{
				$_result[2] = $Action['Attribute']['AttributeValue']['value'];
			}
			else
			{
				$_result[2] = "";
			}
		}
	}
}

$XA_request = "Rq::=<"."{".$_result[0]."}".","."{".$_result[1]."}".","."{".$_result[2]."}".">";

// write the data to a file
fwrite ($output_file, $XA_request);
fclose($output_file);
?>
