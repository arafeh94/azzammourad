<?php

/**
 * SBA Analyzer - Performs policy analysis.
*/

// SBA loader for SBA Policy
require_once('SBA_Loader_Analysis.php');

// $stack is the array holding the based policy data
$Array_count = count($stack);
$Policy_stack = array();
global $PS_Name;
$PS_Name = $stack[0][0];

global $FS;
$FS = array();
global $RS;
$RS = array();
global $CS;
$CS = array();

for ($i = 0;$i < $Array_count;$i++)
{
	$key = 	substr($stack[$i][0],0,-3);
	$Policy_stack[$key] = $stack[$i];
}

/*******************************************************
********* function Display_Response  *******************
// Input - takes 1 array of decisions                 //
// function calls - none                              //
// Output - display the array results to the terminal //
*///////////////////////////////////////////////////////
function display ($array)
{
	echo "<pre>";
	print_r ($array);
	echo "<pre/>";
}
//display($Policy_stack);

/*******************************************************
********* function PolicySet_Analysis  *****************
// Input - takes 1 PolicySet                          //
// function calls - Rule_Analysis                     //
// Output - display the Analysis report terminal/file //
*///////////////////////////////////////////////////////

function PolicySet_Analysis($PolicySet,$PS_Name)
{

	// Number of Policies in the PS
	$P_count = 0;
	// trim ::
	$PS_Name = substr($PS_Name,0,-3);

	if (isset($PolicySet[$PS_Name][1]))
	{
		$P_count = count ($PolicySet[$PS_Name][1]);
	}

	if ($P_count == 1)
	{
		// Call Policy Analysis
		$Pi = "P::".$PolicySet[$PS_Name][1][0];
		$Result = Policy_Analysis($PolicySet[$Pi],'',$PolicySet);
		echo $Result;
		if (isset($Result[0]))
		{
			if (isset($FS[0]))
			{
				$FS[0] = $FS[0]."|".$Result[0];
			}
			else
			{
				$FS[0] = $Result[0];
			}
		}
		if (isset($Result[1]))
		{
			if (isset($RS[0]))
			{
				$RS[0] = $RS[0]."|".$Result[1];
			}
			else
			{
				$RS[0] = $Result[1];
			}
		}
		if (isset($Result[2]))
		{
			if (isset($CS[0]))
			{
				$CS[0] = $CS[0]."|".$Result[2];
			}
			else
			{
				$CS[0] = $Result[2];
			}
		}
	}
	else
	{
		// loop thru the policies in PS
		for ($i = 0;$i < ($P_count - 1); $i++)
		{
			for ($j = $i+1;$j <= ($P_count - 1); $j++)
			{
				// Call Policy Analysis
				$Pi = "P::".$PolicySet[$PS_Name][1][$i];
				$Pj = "P::".$PolicySet[$PS_Name][1][$j];
				$Result = Policy_Analysis($PolicySet[$Pi],$PolicySet[$Pj],$PolicySet);
				if (isset($Result[0]))
				{
					if (isset($FS[0]))
					{
						$FS[0] = $FS[0]."|".$Result[0];
					}
					else
					{
						$FS[0] = $Result[0];
					}
				}
				if (isset($Result[1]))
				{
					if (isset($RS[0]))
					{
						$RS[0] = $RS[0]."|".$Result[1];
					}
					else
					{
						$RS[0] = $Result[1];
					}
				}
				if (isset($Result[2]))
				{
					if (isset($CS[0]))
					{
						$CS[0] = $CS[0]."|".$Result[2];
					}
					else
					{
						$CS[0] = $Result[2];
					}
				}
			}
		}
	}
	if (!isset($FS))
	{
		$FS[0] = "";
	}
	if (!isset($RS))
	{
		$RS[0] = "";
	}
	if (!isset($CS))
	{
		$CS[0] = "";
	}
	Display_Report($FS,$RS,$CS);
}

// Call Function PolicySet
PolicySet_Analysis($Policy_stack,$PS_Name);
//Display_Report();

/*******************************************************
********* function PolicySet_Analysis  *****************
// Input - takes 2 Policies                           //
// function calls - Rule_Analysis                     //
// Output - None									  //
*///////////////////////////////////////////////////////

function Policy_Analysis($Policy1,$Policy2,$BasedPolicy)
{
	$P_count = 0;
	$p = 2;
	$Results = array();
	if (empty($Policy2))
	{
		$p = 1;
	}
	for ($l = 1; $l <= $p; $l++)
	{
		if ($l == 1)
		{
			$P_count = count($Policy1[1]);
			$Policy = $Policy1;
		}
		else
		{
			$P_count = count($Policy2[1]);
			$Policy = $Policy2;
		}
		// Loop Through
		for ($i = 0; $i < ($P_count - 1); $i++)
		{
			for ($j = $i + 1; $j < $P_count; $j++)
			{
				$R1 = "R::".$Policy[1][$i];
				$R2 = "R::".$Policy[1][$j];
				$RA = Rule_Analysis_Flaw($BasedPolicy[$R1],$BasedPolicy[$R2]);
				// based on the response from RA append to the proper queue
				if ($RA == "Flaw")
				{
					if (isset($FS[0]))
					{
						$FS[0] = $FS[0]."|"."Flaw_".$Policy[1][$i].",".$Policy[1][$j];
					}
					else
					{
						$FS[0] = "Flaw_".$Policy[1][$i].",".$Policy[1][$j];
					}
				}
				$RA = Rule_Analysis_Redundant_Conflict($BasedPolicy[$R1],$BasedPolicy[$R2]);
				if ($RA == "Redundant")
				{
					if (isset($RS[0]))
					{
						$RS[0] = $RS[0]."|"."Redundant_".$Policy[1][$i].",".$Policy[1][$j];
					}
					else
					{

						$RS[0] = "Redundant_".$Policy[1][$i].",".$Policy[1][$j];
					}
				}
				if ($RA == "Conflict")
				{
					if (isset($CS[0]))
					{
						$CS[0] = $CS[0]."|"."Conflict_".$Policy[1][$i].",".$Policy[1][$j];
					}
					else
					{
						$CS[0] = "Conflict_".$Policy[1][$i].",".$Policy[1][$j];
					}
				}
			}
		}
	}
	if (empty($Policy2))
	{
		//dont know yet
	}
	else
	{
	  if ($Policy1[3] == $Policy2[3])
	  {
		// check if the target of Rule2 intersect with target of Rule1
		if ((Intersect ($Policy1[5][0],$Policy2[5][0]) == 'True') && (Intersect ($Policy1[5][1],$Policy2[5][1]) == 'True') && (Intersect ($Policy1[5][2],$Policy2[5][2]) == 'True'))
		{
			for ($l = 0; $l < count ($Policy1[1]); $l++)
			{
				for ($m = 0; $m < count ($Policy2[1]); $m++)
				{
					$R1 = "R::".$Policy1[1][$l];
					$R2 = "R::".$Policy2[1][$m];
					$RA = Rule_Analysis_Flaw($BasedPolicy[$R1],$BasedPolicy[$R2]);
					if ($RA == "Flaw")
					{
						if (isset($FS[0]))
						{
							$FS[0] = $FS[0]."|"."Flaw_".$Policy1[1][$l].",".$Policy2[1][$m];
						}
						else
						{
							$FS[0] = "Flaw_".$Policy1[1][$m].",".$Policy2[1][$m];
						}
					}
					$RA = Rule_Analysis_Redundant_Conflict($BasedPolicy[$R1],$BasedPolicy[$R2]);
					if ($RA == "Redundant")
					{
						$RS[1] = "yes";
						if (isset($RS[0]))
						{
							$RS[0] = $RS[0]."|"."Redundant_".$Policy1[1][$l].",".$Policy2[1][$m];
						}
						else
						{
							$RS[0] = "Redundant_".$Policy1[1][$l].",".$Policy2[1][$m];
						}
					}
					if ($RA == "Conflict")
					{
						$CS[1] = "yes";
						if (isset($CS[0]))
						{
							$CS[0] = $CS[0]."|"."Conflict_".$Policy1[1][$l].",".$Policy2[1][$m];
						}
						else
						{
							$CS[0] = "Conflict_".$Policy1[1][$l].",".$Policy2[1][$m];
						}
					}
				}
			}
		}
	  }
	}
	// Check if 2 different rules from 2 different policy (flaw,conflict,redundant)
	if (isset ($FS[1]))
	{
		unset($FS[1]);
		$FS[0] = $FS[0]."|Flaw_".substr(substr($Policy1[0],3,-1),0,-2).",".substr(substr($Policy2[0],3,-1),0,-2);
	}
	if (isset($RS[1]))
	{
		unset($RS[1]);
		$RS[0] = $RS[0]."|Redundant_".substr(substr($Policy1[0],3,-1),0,-2).",".substr(substr($Policy2[0],3,-1),0,-2);
	}
	if (isset($CS[1]))
	{
		unset($CS[1]);
		$CS[0] = $CS[0]."|Conflict_".substr(substr($Policy1[0],3,-1),0,-2).",".substr(substr($Policy2[0],3,-1),0,-2);
	}
	if (isset($FS[0]))
	{
		$Results[0] = $FS[0];

	}
	if (isset($RS[0]))
	{
		$Results[1] = $RS[0];
	}
	if (isset($CS[0]))
	{
		$Results[2] = $CS[0];
	}

	return ($Results);
}

/*******************************************************
********* function Rule_Analysis_Flaw *******************
// Input - takes 2 rules                              //
// function calls - none                              //
// Output - Returns Flaw, null   //
*///////////////////////////////////////////////////////

function Rule_Analysis_Flaw ($rule1,$rule2)
{
	// Rule effect of R1 and R2
	$RE1 = $rule1[3];
	$RE2 = $rule2[3];

	// check if subjects of Rule2 subset of Rule1, Resources of Rule2 subset of rule1, Actions of Rule2 subset of Rule1
	if ((Subset($rule1[2][0],$rule2[2][0]) == 'True') && (Subset($rule1[2][1],$rule2[2][1]) == 'True') && (Subset($rule1[2][2],$rule2[2][2]) == 'True'))
	{
		// Check if RC2 is a subset of RC1
		if (Rule_Condition_Subset($rule1[1],$rule2[1]) == 'True')
		{
			// check if rules rule1 and rule2 have same effect
			if (strtoupper($rule1[3]) == strtoupper($rule2[3]))
			{
				$response = "Flaw";
				return $response;
			}
		}
	}
}

/*******************************************************
********* function Rule_Analysis_Redundant_Conflict ****
// Input - takes 2 rules                              //
// function calls - none                              //
// Output - Returns Redundant, Conflict, null         //
*///////////////////////////////////////////////////////

function Rule_Analysis_Redundant_Conflict ($rule1,$rule2)
{
	// Rule effect of R1 and R2
	$RE1 = $rule1[3];
	$RE2 = $rule2[3];
	// check if the target of Rule2 intersect with target of Rule1
	if ((Intersect ($rule1[2][0],$rule2[2][0]) == 'True') && (Intersect ($rule1[2][1],$rule2[2][1]) == 'True') && (Intersect ($rule1[2][2],$rule2[2][2]) == 'True'))
	{
		// Check if RC1 and RC2 intersect
		if (Rule_Condition_Intersect ($rule1[1],$rule2[1]) == 'True')
		{
			if ($RE1 != $RE2)
			{
				$response = "Conflict";
				return $response;
			}
			else
			{
				$response = "Redundant";
				return $response;
			}
		}
	}
}

/*******************************************************
********* function Rule_Condition_Intersect**************
// Input - takes 2 arrays                              //
// function calls - none                               //
// Output - True or False                              //
*///////////////////////////////////////////////////////

function Rule_Condition_Intersect ($array1,$array2)
{
	$response = "";
	$match = 0;
	$RC1 = Reformat_Rule_condition($array1);
	$RC2 = Reformat_Rule_condition($array2);

 	$count1 = count($RC1);
	$count2 = count($RC2);
	if ($count1 == 0 | $count2 == 0)
	{
		$response = "True";
		return $response;
	}
	// one condition no and/or
	if($count1 == 1)
	{
		// 1 - 1 condition
		if ($count2 == 1)
		{
			// Both RC1 and RC2 have the same cond. 1-1 condition
			$Array_intersect = array_intersect($RC1,$RC2);
			if ($Array_intersect == $RC1)
			{
				$response = "True";
				return $response;
			}
			else
			{
				$response = "False";
				return $response;
			}
		}
		else
		{
			// 1 - many with RC2 has "and"
			if ($RC2[0] == "and")
			{
				// Both RC1 and RC2 have the same cond. 1-1 condition
				$Array_intersect = array_intersect($RC1,array_slice($RC2,1));
				if ($Array_intersect == $RC1)
				{
					$response = "True";
					return $response;
				}
				else
				{
					//display($array1);
					//display($RC2);
					// both conditions deal with time
					if ((substr($RC1[0],0,4) == 'time') && (substr($RC2[1],0,4) == 'time'))
					{
						if ($array1[0] == $array2[1])
						{
							$explode_array1_s=explode(",",$array1[1],3);
							$explode_array2_s=explode(",",$array2[2],3);
							$explode_array2_e=explode(",",$array2[4],3);
							$x = 24 - $explode_array2_s[2];
							$y = $explode_array2_e[2] - $explode_array1_s[2];
							if ($x >= 0 && $y >= 0)
							{
								$response = "True";
								return $response;
							}
							else
							{
								$response = "False";
								return $response;
							}
						}
						else
						{
							if ($array1[0] == $array2[3])
							{
								$explode_array1_e=explode(",",$array1[1],3);
								$explode_array2_s=explode(",",$array2[2],3);
								$explode_array2_e=explode(",",$array2[4],3);
								$x = $explode_array1_e[2] - $explode_array2_s[2];
								$y = $explode_array2_e[2] - 0;
								if ($x >= 0 && $y >= 0)
								{
									$response = "True";
									return $response;
								}
								else
								{
									$response = "False";
									return $response;
								}
							}
							else
							{
								$response = "False";
								return $response;
							}
						}
					}
					else
					{
						$response = "False";
						return $response;
					}
				}
			}
			else
			{
				// 1 - many with RC2 has "or"
				if ($RC2[0] == "or")
				{
					$Array_intersect = array_intersect($RC1,array_slice($RC2,1));
					if ($Array_intersect)
					{
						$response = "True";
						return $response;
					}
					else
					{
						$response = "False";
						return $response;
					}
				}
				else
				{
					$response = "Unknown";
					return $response;
				}
			}
		}
	}
	else
	{
		// RC1 has many conds with RC1 has "and"
		if ($RC1[0] == "and")
		{
			if ($count2 == 1)
			{
				$Array_intersect = array_intersect(array_slice($RC1,1),$RC2);
				if ($Array_intersect == $RC2)
				{
					$response = "True";
					return $response;
				}
				else
				{
					$response = "False";
					return $response;
				}
			}
			else
			{
				// RC2 has many conds with RC2 has "and"
				if($RC2[0] == "and")
				{
					$Array_intersect = array_intersect(array_slice($RC1,1),array_slice($RC2,1));
					if ($Array_intersect == array_slice($RC1,1))
					{
						$response = "True";
						return $response;
					}
					else
					{
						// both conditions deal with time
						if ((substr($RC1[1],0,4) == 'time') && (substr($RC2[1],0,4) == 'time'))
						{
							if ($array1[1] == $array2[1])
							{
								if ($array1[3] == $array2[3])
								{
									$explode_array1_s=explode(",",$array1[2],3);
									$explode_array2_s=explode(",",$array2[2],3);
									$explode_array1_e=explode(",",$array1[4],3);
									$explode_array2_e=explode(",",$array2[4],3);
									$x = $explode_array1_e[2] - $explode_array2_s[2];
									$y = $explode_array2_e[2] - $explode_array1_s[2];
									if ($x >= 0 && $y >= 0)
									{
										$response = "True";
										return $response;
									}
									else
									{
										$response = "False";
										return $response;
									}
								}
							}
							else
							{
								$response = "False";
								return $response;
							}
						}
						else
						{
							$response = "False";
							return $response;
						}
					}
				}
				else
				{
					// RC2 has many conds with RC2 has "or"
					if($RC2[0] == "or")
					{
						$Array_intersect = array_intersect(array_slice($RC1,1),array_slice($RC2,1));
						if ($Array_intersect == array_slice($RC1,1))
						{
							$response = "True";
							return $response;
						}
						else
						{
							$response = "False";
							return $response;
						}
					}
					else
					{
						$response = "Unknown";
						return $response;
					}
				}
			}
		}
		else
		{
			// RC1 has many conds with RC1 has "or"
			if ($RC1[0] == "or")
			{
				// RC2 has one cond.
				if($count2 == 1)
				{
					$Array_intersect = array_intersect(array_slice($RC1,1),$RC2);
					if ($Array_intersect == $RC2)
					{
						$response = "True";
						return $response;
					}
					else
					{
						$response = "False";
						return $response;
					}
				}
				else
				{
					// RC2 has many conds with RC2 has "and"
					if ($RC2[0] == "and")
					{
						$Array_intersect = array_intersect(array_slice($RC1,1),array_slice($RC2,1));
						if ($Array_intersect == array_slice($RC2,1))
						{
							$response = "True";
							return $response;
						}
						else
						{
							$response = "False";
							return $response;
						}
					}
					else
					{
						if($RC2[0] == "or")
						{
							$Array_intersect = array_intersect(array_slice($RC1,1),array_slice($RC2,1));
							if ($Array_intersect)
							{
								$response = "True";
								return $response;
							}
							else
							{
								$response = "False";
								return $response;
							}
						}
						else
						{
							$response = "Unknown";
							return $response;
						}
					}
				}
			}
		}
	}

}

/*******************************************************
********* function Rule_Condition_Subset  **************
// Input - takes 2 arrays                              //
// function calls - none                               //
// Output - True or False                              //
*///////////////////////////////////////////////////////

function Rule_Condition_Subset ($array1,$array2)
{
	$response = "";
	$match = 0;
	$RC1 = Reformat_Rule_condition($array1);
	$RC2 = Reformat_Rule_condition($array2);
	$count1 = count($RC1);
	$count2 = count($RC2);
	if ($count1 == 0 && $count2 == 0)
	{
		$response = "True";
		return $response;
	}
	if ($count1 == 0 && $count2 != 0)
	{
		$response = "True";
		return $response;
	}
	if ($count1 != 0 && $count2 == 0)
	{
		$response = "False";
		return $response;
	}
	// one condition no and/or
	if($count1 == 1)
	{
		// 1 - 1 condition
		if ($count2 == 1)
		{
			// Both RC1 and RC2 have the same cond. 1-1 condition
			$Array_intersect = array_intersect($RC1,$RC2);
			if ($Array_intersect == $RC1)
			{
				$response = "True";
				return $response;
			}
			else
			{
				$response = "False";
				return $response;
			}
		}
		else
		{
			// 1 - many with RC2 has "and"
			if ($RC2[0] == "and")
			{
				// Both RC1 and RC2 have the same cond. 1-1 condition
				$Array_intersect = array_intersect($RC1,$RC2);
				if ($Array_intersect == $RC1)
				{
					$response = "True";
					return $response;
				}
				else
				{
					// both conditions deal with time
					if ((substr($RC1[0],0,4) == 'time') && (substr($RC2[1],0,4) == 'time'))
					{
						if ($array1[0] == $array2[1])
						{
							$explode_array1=explode(",",$array1[1],3);
							$explode_array2=explode(",",$array2[2],3);
							if ($explode_array1[2] <= $explode_array2[2])
							{
								$response = "True";
								return $response;
							}
							else
							{
								$response = "False";
								return $response;
							}
						}
						else
						{
							if ($array1[0] == $array2[3])
							{
								$explode_array1=explode(",",$array1[1],3);
								$explode_array2=explode(",",$array2[4],3);
								if ($explode_array1[2] >= $explode_array2[2])
								{
									$response = "True";
									return $response;
								}
								else
								{
									$response = "False";
									return $response;
								}
							}

						}
					}
					else
					{
						$response = "False";
						return $response;
					}
				}
			}
			else
			{
				// 1 - many with RC2 has "or"
				if ($RC2[0] == "or")
				{
					$response = "False";
					return $response;
				}
				else
				{
					$response = "Unknown";
					return $response;
				}
			}
		}
	}
	else
	{
		// RC1 has many conds with RC1 has "and"
		if ($RC1[0] == "and")
		{
			if ($count2 == 1)
			{
				$response = "False";
				return $response;
			}
			else
			{
				// both conds. have more than 1 conditions and both have and as apply
				// RC2 has many conds with RC2 has "and"
				if($RC2[0] == "and")
				{
					$Array_intersect = array_intersect($RC1,$RC2);
					if ($Array_intersect == $RC1)
					{
						$response = "True";
						return $response;
					}
					else
					{
						// both conditions deal with time
						if ((substr($RC1[1],0,4) == 'time') && (substr($RC2[1],0,4) == 'time'))
						{
							display ($RC1);
							display ($RC2);
							if ($array1[1] == $array2[1])
							{
								if ($array1[3] == $array2[3])
								{
									$explode_array1=explode(",",$array1[2],3);
									$explode_array2=explode(",",$array2[2],3);
									if ($explode_array1[2] <= $explode_array2[2])
									{
										$explode_array1=explode(",",$array1[4],3);
										$explode_array2=explode(",",$array2[4],3);
										if ($explode_array1[2] >= $explode_array2[2])
										{
											$response = "True";
											return $response;
										}
										else
										{
											$response = "False";
											return $response;
										}
									}
									else
									{
										$response = "False";
										return $response;
									}
								}
								else
								{
									$response = "False";
									return $response;
								}
							}
							else
							{
								$response = "False";
								return $response;
							}
						}
						else
						{
							$response = "False";
							return $response;
						}
					}
				}
				else
				{
					// RC2 has many conds with RC2 has "or"
					if($RC2[0] == "or")
					{
						$response = "False";
						return $response;
					}
					else
					{
						$response = "Unknown";
						return $response;
					}
				}
			}
		}
		else
		{
			// RC1 has many conds with RC1 has "or"
			if ($RC1[0] == "or")
			{
				// RC2 has one cond.
				if($count2 == 1)
				{
					$Array_intersect = array_intersect($RC1,$RC2);
					if ($Array_intersect == $RC2)
					{
						$response = "True";
						return $response;
					}
				}
				else
				{
					// RC2 has many conds with RC2 has "and"
					if ($RC2[0] == "and")
					{
						$Array_intersect = array_intersect($RC1,$RC2);
						if ($Array_intersect)
						{
							$response = "True";
							return $response;
						}
						else
						{
							$response = "False";
							return $response;
						}
					}
					else
					{
						if($RC2[0] == "or")
						{
							$Array_intersect = array_intersect($RC1,$RC2);
							if ($Array_intersect == $RC1)
							{
								$response = "True";
								return $response;
							}
							else
							{
								$response = "False";
								return $response;
							}
						}
						else
						{
							$response = "Unknown";
							return $response;
						}
					}
				}
			}
		}
	}
}


/*******************************************************
********* function Reformat_Rule_Condition **************
// Input - takes 1 array                              //
// function calls - none                               //
// Output - 1 array                                   //
*///////////////////////////////////////////////////////

function Reformat_Rule_Condition ($array1)
{
	$count1 = count($array1);
	$RC1 = array();
	$j = -1;
	for ($i = 0; $i < $count1; $i++)
	{
		if (isset($array1[$i]) && $array1[$i] != '')
		{
			$j++;
			if ($array1[$i] == "and" | $array1[$i] == "or")
			{
				$RC1[$j] = $array1[$i];
			}
			else
			{
				if(isset($RC1[$j]))
				{
					$RC1[$j] = $RC1[$j].",".$array1[$i].",".$array1[$i++];
				}
				else
				{
					$RC1[$j] = $array1[$i].",".$array1[++$i];
				}
			}
		}
	}
	return $RC1;
}

/*******************************************************
********* function Subset          **********************
// Input - takes 2 arrays                              //
// function calls - none                               //
// Output - True or False                              //
*///////////////////////////////////////////////////////

function Subset ($array1,$array2)
{
	$response = "";
	$Array_intersect = array_intersect($array1,$array2);
	// if insection set is equal to array2
	if ($Array_intersect == $array2)
	{
		$response = 'True';
	}
	else
	{
		$response = 'False';
	}
	return $response;
}




/*******************************************************
********* function Intersect      **********************
// Input - takes 2 arrays                              //
// function calls - none                               //
// Output - True or False                              //
*///////////////////////////////////////////////////////

function Intersect ($array1,$array2)
{
	$response = "";
	if (($array1[0] == 'Any') | ($array1[0] == ''))
	{
		$response = "True";
		return $response;
	}
	if (($array2[0] == 'Any') | ($array2[0] == ''))
	{
		$response = "True";
		return $response;
	}
	// check if array1 is set
	if (isset ($array1))
	{
		if (isset ($array2))
		{
			$Array_intersect = array_intersect($array2,$array1);
			if (isset($Array_intersect))
			{
				if (empty($Array_intersect))
				{
					// no intersection
					$response = "False";
				}
				else
				{
					$response = "True";
				}
			}
		}
	}
	else
	{
		$response = "True";
	}
	return $response;
}

Function Display_Report($FS,$RS,$CS)
{
	echo "<pre>";
	echo "Flaws found: <br><br>";
	if (empty ($FS[0]))
	{
		echo "Flaw Set FS = {}";
	}
	else
	{
		echo "Flaw Set FS = ".str_replace("|",', ', "{".implode('|',array_unique(explode('|', $FS[0])))."}");

	}
	echo "<br><br>";
	echo "Redundancies found: <br><br>";
	if (empty ($RS[0]))
	{
		echo "Redundancy Set RS = {}";
	}
	else
	{
		 echo "Redundancy Set RS = ".str_replace("|",', ', "{".implode('|',array_unique(explode('|', $RS[0])))."}");
	}
	echo "<br><br>";
	echo "Conflicts found: <br><br>";
	if (empty ($CS[0]))
	{
		echo "Conflict Set CS = {}";
	}
	else
	{
		echo "Conflict Set CS = ".str_replace("|",', ', "{".implode('|',array_unique(explode('|', $CS[0])))."}");

	}
	echo "</pre>";
}
?>