<?php

/**
 * XA_Engine Evaluates the Request against the XA Policy.
*/

// SBA Based Policy Loader
require_once('SBA_Policy_Loader.php');

// SBA Request Loader
require_once('SBA_Request_Loader.php');
// $Request_stack

// $stack is the base policy array
$Policy_stack = $stack;
// $stack

/*******************************************************
********* function Display_Response  *******************
// Input - takes 1 array of decisions                 //
// function calls - none                              //
// Output - display the array results to the terminal //
*///////////////////////////////////////////////////////

function Display_Response ($_Response)
{
	echo "<pre>";
	echo "<b>Final Decision = </b>$_Response[4]";
	echo "<br><br>";
	$_number_Policies_Processed = $_Response[0] + $_Response[1] + $_Response[2] + $_Response[3];
	echo "<b>Total Number of Policies processed = </b>".$_number_Policies_Processed;
	echo "<br><br>";
	echo "<b>Result Summary of Processed policies </b>";
	echo "<br><br>";
	echo "<b>Number of Policies Evaluated to permit        = </b>$_Response[0]";
	echo "<br>";
	echo "<b>Number of Policies Evaluated to Deny          = </b>$_Response[1]";
	echo "<br>";
	echo "<b>Number of Policies Evaluated to NotApplicable = </b>$_Response[2]";
	echo "<br>";
	echo "<b>Number of Policies Evaluated to Indeterminate = </b>$_Response[3]";
	echo "</pre>";
}

/*****************************************************
********* function Combinig_Algorithm*****************
// Input - takes 1 array of decisions               //
// function calls - none                            //
// Output - returns an Array of combined decision   //
*/////////////////////////////////////////////////////

function Combinig_Algorithm($_Response)
{
	// Matrix for the combining Algorithm

	// [0] --> number of permits
	// [1] --> number of denies
	// [2] --> number of N/A
	// [3] --> number of Indeterminate

 	if ($_Response[4] == '')
	{
		// if the Policy Combining is Permit overrides and no policies evaluated to Permit
		if (strtoupper ($_Response[5]) == 'PERMIT-OVERRIDES')
		{
			// IF ANY POLICIES EVALUATED TO DENY
			if($_Response[1] > 0)
			{
				// 'Deny';
				$_Response[4] = 'Deny';
			}
			else
			{
				if($_Response[2] > 0)
				{
					// 'NotApplicable';
					$_Response[4] = 'NotApplicable';
				}
				else	// Default to indeterminate
				{
					// 'Indeterminate';
					$_Response[4] = 'Indeterminate';

				}
			}
		}

		// if the Policy Combining is Deny overrides and no policies evaluated to Deny
		if (strtoupper ($_Response[5]) == 'DENY-OVERRIDES')
		{
			// IF ANY POLICIES EVALUATED TO Permit
			if($_Response[0] > 0)
			{
					// 'Permit';
					$_Response[4] = 'Permit';
			}
			else	// no policies evaluated to permit
			{
				// if any evaluated to NotApplicable
				if($_Response[2] > 0)
				{
						// 'NotApplicable';
						$_Response[4] = 'NotApplicable';
				}
				else	// Default to indeterminate
				{
					// 'Indeterminate';
					$_Response[4] = 'Indeterminate';
				}

			}
		}
	}
	return $_Response;
}

/****************************************************
********* function Target_Comparison*****************
// Input - takes 2 arrays, request and target      //
// function calls - none                           //
// Output - returns true or false                  //
*////////////////////////////////////////////////////

function Target_Comparison ($Request,$Policy_Target)
{
	// default the result to false
	$result = "false";

	// count the number of elements in the Request
	$Request_number = count($Request);
	//var_dump($Request);
	// count the number of elements in the Policy Target
	$Policy_number  = count($Policy_Target);
	//var_dump($Policy_Target);
	// loop through the request
	for ($Request_loop = 0; $Request_loop < $Request_number; $Request_loop++)
	{
		// loop through the Policy Target
		for ($Policy_loop = 0; $Policy_loop < $Policy_number; $Policy_loop++)
		{
			// If PS/Policy/Rule does not specify a values for either subject/resource/action
			if ($Policy_Target[$Policy_loop] == '')
			{
				$result =  "true";
				break;
			}
			// If PS/Policy/Rule has a value of ANY for either subject/resource/action
			if (strtoupper ($Policy_Target[$Policy_loop]) == 'ANY')
			{
				$result =  "true";
				break;
			}

			if (strtoupper($Request[$Request_loop]) == strtoupper($Policy_Target[$Policy_loop]))
			{
				//var_dump($Request[$Request_loop]);
				$result =  "true";
			}
			else
			{
				$result =  "false";
			}
		}
	}

	// returned result is either true or false
	return $result;
}


/*************************************************************
//********* function PolicySet_Evaluation*********************
// Input - takes 2 arrays, request and base policy          //
// function calls Target_comparison &                       //
//                Policy_Evaluation and Combining_Algorithm //
// Output - returns an array of responses                   //
*/////////////////////////////////////////////////////////////

function PolicySet_Evaluation ($_Policy_stack,$_Request_stack)
{

	// initialize varriable to keep track of number of targets match at the policy level
	$number_of_policies_match_by_target = 0;

	// initialize varriable to keep track of sum of applicable policies
	$_sum_of_Applicable = 0;

	// initialize the Array to keep track of the Evaluation
	$_PolicySet_Eval = array(0,0,0,0,"","");

	// call Target comparison for subjects, Resources and Actions
	for ($index = 1; $index <= 3; $index++)
	{
		$index_Policy = $index - 1;
		// Call function target compare to compare request S,R and with target Subj, Resources and Actions
		if (empty ($_Policy_stack[0][6][$index_Policy]))
		{
			$PS_Target = 'true';
		}
		else
		{
			//var_dump($_Policy_stack[0][6][$index_Policy]);
			$PS_Target = Target_Comparison ($_Request_stack[0][$index],$_Policy_stack[0][6][$index_Policy]);
			if ($PS_Target == "false")
			{
				$_PolicySet_Eval[4] = "NotApplicable";
				return $_PolicySet_Eval;
			}
		}
	}
	// Target Match
	if ($PS_Target == "true")
	{
		// get the number policies from the policy set att. 1
		$_number_of_policies = count ($_Policy_stack[0][1]);

		// if there are no Policies defined then return
		if ($_number_of_policies == 1)
		{
			if ($_Policy_stack[0][1][0] == "")
			{
				$_PolicySet_Eval[4] = 'NOTAPPLICABLE';
				return $_PolicySet_Eval;
			}
		}

		// Policy index usually starts at 1 assuming Policy set is at 0
		$_policy_index = 1;

		// $_Policy_stack[0][1] contains the names of the policies
		// take one Policy at a time and evaluate
		for($_policy = 0; $_policy < $_number_of_policies; $_policy++)
		{
			// loop and find the correct Policy and call policy evaluation
			while (isset($_Policy_stack[$_policy_index]))
			{
				// get the policy array
				if (substr ($_Policy_stack[$_policy_index][0],3,-3) == $_Policy_stack[0][1][$_policy] & substr ($_Policy_stack[$_policy_index][0],0,3) == 'P::')
				{
					// call policy evaluation
					$_Policy_Eval = Policy_Evaluation($_Policy_stack[$_policy_index],$_Request_stack[0],$_Policy_stack,$_policy_index);
					{
						// Combining Alg. returns the final decision from the Policy evaluation
						//if (strtoupper ($_Policy_stack[0][3]) <> 'ONLY-ONE-APPLICABLE')
						{
							$_Policy_Eval = Combinig_Algorithm ($_Policy_Eval);
						}
						// Policy evaluation
						// At least one permits -- if all evaluate to deny then the decision is deny
						if (strtoupper ($_Policy_stack[0][3]) == 'PERMIT-OVERRIDES')
						{
							$_PolicySet_Eval[5] = $_Policy_stack[0][3];
							// if one Policy evaluates to permit ==> Permit
							if (strtoupper ($_Policy_Eval[4]) == 'PERMIT')
							{
								$_PolicySet_Eval[0]++;
								$_PolicySet_Eval[4] = $_Policy_Eval[4];
								return $_PolicySet_Eval;
							}
							// If current policy evaluates to Deny == > Continue to the next
							if (strtoupper ($_Policy_Eval[4]) == 'DENY')
							{
								$_PolicySet_Eval[1]++;
							}
							// If current policy evaluates to n/a == > Continue to the next
							if (strtoupper ($_Policy_Eval[4]) == 'NOTAPPLICABLE')
							{
								$_PolicySet_Eval[2]++;
							}
							// If current policy evaluates to INDETER. == > Continue to the next
							if (strtoupper ($_Policy_Eval[4]) == 'INDETERMINATE')
							{
								$_PolicySet_Eval[3]++;
							}

						}
						// At least one denies --> if no deny continue to the next rule -- if all permit then the decision is permit
						if (strtoupper ($_Policy_stack[0][3]) == 'DENY-OVERRIDES')
						{
							// assign PolicyComb.Alg. to att. 5.
							$_PolicySet_Eval[5] = $_Policy_stack[0][3];
							// if one Policy evaluates to Permit == > keep going
							if (strtoupper ($_Policy_Eval[4]) == 'PERMIT')
							{
								$_PolicySet_Eval[0]++;
							}
							// if one Policy evaluates to Deny == > Deny
							if (strtoupper ($_Policy_Eval[4]) == 'DENY')
							{
								$_PolicySet_Eval[1]++;
								$_PolicySet_Eval[4] = $_Policy_Eval[4];
								return $_PolicySet_Eval;
							}
							// if one Policy evaluates to N/A ==> Keep going
							if (strtoupper ($_Policy_Eval[4]) == 'NOTAPPLICABLE')
							{
								$_PolicySet_Eval[2]++;
							}
							// if one Policy evaluates to INDETERMINATE ==> Keep going
							if (strtoupper ($_Policy_Eval[4]) == 'INDETERMINATE')
							{
								$_PolicySet_Eval[3]++;
							}

						}
						// first applicable -- keep evaluating rules till the first applicable
						if (strtoupper ($_Policy_stack[0][3]) == 'FIRST-APPLICABLE')
						{
							$_PolicySet_Eval[4] = 'NOTAPPLICABLE';
							// The first Policy evaluates to Applicable == >
							if (strtoupper ($_Policy_Eval[4]) <> 'NOTAPPLICABLE')
							{
								$_PolicySet_Eval = $_Policy_Eval;
								return $_PolicySet_Eval;
							}
						}
						// only one applicable - if more than one applicable then the decision is indeterminate
						if (strtoupper ($_Policy_stack[0][3]) == 'ONLY-ONE-APPLICABLE')
						{
							$number_of_policies_match_by_target = $number_of_policies_match_by_target + $_Policy_Eval[6];
							$_Policy_Eval[6] = 0;
							//var_dump($_PolicySet_Eval);
							if ($number_of_policies_match_by_target > 1)
							{
									$_PolicySet_Eval[4] = 'INDETERMINATE';
									return $_PolicySet_Eval;

							}
							// if the Policy evaluates to Applicable Permit
							if (strtoupper ($_Policy_Eval[4]) == 'PERMIT')
							{
								$_PolicySet_Eval[0]++;
							}
							// if the Policy evaluates to Applicable Permit
							if (strtoupper ($_Policy_Eval[4]) == 'DENY')
							{
								$_PolicySet_Eval[1]++;
							}
							// if the Policy evaluates to Not Applicable == > loop through all policies and decide when all polices evaluated
							if (strtoupper ($_Policy_Eval[4]) == 'NOTAPPLICABLE')
							{
								$_PolicySet_Eval[2]++;
							}
							// Check if more than one policy is applicable --> if true break and return indeterminate
							$_sum_of_Applicable = $_PolicySet_Eval[0] + $_PolicySet_Eval[1];
							if ($_sum_of_Applicable > 1 )
							{
								$_PolicySet_Eval[4] = 'INDETERMINATE';
								return $_PolicySet_Eval;
							}
							$_count_difference = $_number_of_policies - $_policy;
							if ($_count_difference == 1)
							{
								if (($_PolicySet_Eval[0] == 0) && ($_PolicySet_Eval[1] == 0) && ($_PolicySet_Eval[2] <> 0))
								{
									$_PolicySet_Eval[4] = 'NotApplicable';
									return $_PolicySet_Eval;
								}
								else
								{
									if ($_PolicySet_Eval[0] <> 0)
									{
										$_PolicySet_Eval[4] = 'Permit';
										return $_PolicySet_Eval;
									}
									else
									{
										if ($_PolicySet_Eval[1] <> 0)
										{
											$_PolicySet_Eval[4] = 'Deny';
											return $_PolicySet_Eval;
										}
										else
										{
											$_PolicySet_Eval[4] = 'Indeterminate';
											return $_PolicySet_Eval;
										}
									}
								}
							}
						}

					}
					$_policy_index++;
					break;
				}

				$_policy_index++;
			}
		}

	}
	else	// mis-match 2 types N/A or Indeterminate
	{
		// if N/A
		if ($PS_Target == "false")
		{
			// no Errors
			$_PolicySet_Eval[4] = "NotApplicable";
		}
		else
		{
			// Errors
			$_PolicySet_Eval[4] = "Indeterminate";
		}
	}

	return $_PolicySet_Eval;
}


/**********************************************************
********* function Policy_Evaluation***********************
// Input - takes 3 arrays and an index                   //
// function calls Target_comparison and Rule_Evaluation  //
// Output - returns and array of decisions               //
*//////////////////////////////////////////////////////////

function Policy_Evaluation($_Policy_stack,$_Request_stack,$_W_Policy_stack,$_array_index)
{
	$_Policy_Eval = array(0,0,0,0,"","",0);
	// policy passed from PS Eval

	// set the start index at the Policy line
	$_rule_index = $_array_index;

	// call Target comparison for subjects, Resources and Actions
	for ($index = 1; $index <= 3; $index++)
	{
		$index_Policy = $index - 1;
		// Call function target compare to compare request S,R and with target Subj, Resources and Actions
		if (empty($_Policy_stack[5][$index_Policy]))
		{
			$P_Target == "true";
		}
		else
		{
			$P_Target = Target_Comparison ($_Request_stack[$index],$_Policy_stack[5][$index_Policy]);
			if ($P_Target == "false")
			{
				$_Policy_Eval[4] = "NotApplicable";
				return $_Policy_Eval;
			}
		}
	}

	// target matching
	if ($P_Target == "true")
	{
		$_Policy_Eval[6] = $_Policy_Eval[6] + 1;
		// get the number rules from att. 1
		$_number_of_rules = count ($_Policy_stack[1]);

 		for($_rule = 0; $_rule < $_number_of_rules; $_rule++)
		{
			// the rule starts on the next index
			$_rule_index++;

			// loop and find the correct rules and call Rule Evaluation
			if (isset($_W_Policy_stack[$_rule_index]))
			{
				// may want to check to make sure the type is R: in case the names are wrong
				if (substr ($_W_Policy_stack[$_rule_index][0],3,-3) == $_Policy_stack[1][$_rule])
				{

					// call Rule_Evaluation and pass it one rule and request S,R,A
					$_Rule_Eval = Rule_Evaluation($_W_Policy_stack[$_rule_index],$_Request_stack);
					{
						// At least one permits -- if all evaluate to deny then the decision is deny
						if (strtoupper ($_Policy_stack[3]) == 'PERMIT-OVERRIDES')
						{
							// Assign the Policy Comb. Alg. to att5.
							$_Policy_Eval[5] = $_Policy_stack[3];
							// if one Policy evaluates to permit ==> Permit
							if (strtoupper ($_Rule_Eval[0]) == 'PERMIT')
							{
								$_Policy_Eval[0]++;
								$_Policy_Eval[4] = $_Rule_Eval[0];
								return $_Policy_Eval;
							}
							// If current policy evaluates to Deny == > Continue to the next
							if (strtoupper ($_Rule_Eval[0]) == 'DENY')
							{
								$_Policy_Eval[1]++;
							}
							// If current policy evaluates to n/a == > Continue to the next
							if (strtoupper ($_Rule_Eval[0]) == 'NOTAPPLICABLE')
							{
								$_Policy_Eval[2]++;
							}
							// If current policy evaluates to INDETER. == > Continue to the next
							if (strtoupper ($_Rule_Eval[0]) == 'INDETERMINATE')
							{
								$_Policy_Eval[3]++;
							}
						}
						// At least one denies --> if no deny continue to the next rule -- if all permit then the decision is permit
						if (strtoupper ($_Policy_stack[3]) == 'DENY-OVERRIDES')
						{
							// Assign the Policy Comb. Alg. to att5.
							$_Policy_Eval[5] = $_Policy_stack[3];
							// if one Policy evaluates to permit ==> Permit
							if (strtoupper ($_Rule_Eval[0]) == 'PERMIT')
							{
								$_Policy_Eval[0]++;
							}
							// If current policy evaluates to Deny == > Continue to the next
							if (strtoupper ($_Rule_Eval[0]) == 'DENY')
							{
								$_Policy_Eval[1]++;
								$_Policy_Eval[4] = $_Rule_Eval[0];
								return $_Policy_Eval;
							}
							// If current policy evaluates to n/a == > Continue to the next
							if (strtoupper ($_Rule_Eval[0]) == 'NOTAPPLICABLE')
							{
								$_Policy_Eval[2]++;
							}
							// If current policy evaluates to INDETER. == > Continue to the next
							if (strtoupper ($_Rule_Eval[0]) == 'INDETERMINATE')
							{
								$_Policy_Eval[3]++;
							}

						}

						// first applicable -- keep evaluating rules till the first applicable rule
						if (strtoupper ($_Policy_stack[3]) == 'FIRST-APPLICABLE')
						{
							// the first rule evaluates to Not Applicable ==> return its result
							if (strtoupper ($_Rule_Eval[0]) <> 'NOTAPPLICABLE')
							{
								$_Policy_Eval[4] = $_Rule_Eval[0];
								return $_Policy_Eval;
							}
							else	// Not applicable -- need to check more into this one!!!!!!!!!!!
							{
								$_Policy_Eval[4] = $_Rule_Eval[0];
							}
						}

					}
				}
			}
		}

	}
	else
	{
		// if N/A
		if ($P_Target == "false")
		{
			// no Errors
			$_Policy_Eval[4] = "NotApplicable";
		}
		else
		{
			// Errors
			$_Policy_Eval[4] = "Indeterminate";
		}
	}
	return $_Policy_Eval;
}

/*******************************************************
********* function Rule_Evaluation**********************
// Input - takes 2 arrays, request and rule           //
// function calls - Target_comparison                 //
// Output - returns an array of decision              //
*///////////////////////////////////////////////////////

function Rule_Evaluation($_Policy_stack,$_Request_stack)
{
	// call Target comparison for subjects, Resources and Actions
	for ($index = 1; $index <= 3; $index++)
	{
		$index_Policy = $index - 1;
		// Call function target compare to compare request S,R and with target Subj, Resources and Actions
		if (empty ($_Policy_stack[2][$index_Policy]))
		{
			$R_Target = 'true';
		}
		else
		{
			$R_Target = Target_Comparison ($_Request_stack[$index],$_Policy_stack[2][$index_Policy]);
			if ($R_Target == "false")
			{
				$result[0] = "NotApplicable";
				$result[1] = 'NO';
				return $result;

			}
		}
	}

	//if the Reuqest target matches the Rule Target   \\ Match case
	if ($R_Target == 'true')
	{
		// check rule conditions
		// default to true for now
		$_RC = 'true';
		// if it evaluates to true then rule effect is returned
		if($_RC == 'true')
		{
			$result[0] = $_Policy_stack[3];
			$result[1] = 'YES';
		}
		else
		{
			// if it evaluates to true then rule effect is returned
			if($_RC == 'false')
			{
				$result[0] = "NotApplicable";
				$result[1] = 'NO';
			}
			else // others
			{
				$result[0] = "Indeterminate";
				$result[1] = 'NO';
			}
		}
	}
	else	// Target doesnt not match at the rule level
	{
		// if N/A
		if ($R_Target == "false")
		{
			// no Errors
			$result[0] = "NotApplicable";
			$result[1] = 'NO';
		}
		else
		{
			// Errors
			$result[0] = "Indeterminate";
			$result[1] = 'NO';
		}
	}

	return $result;
}

// Call Evaluation function
$_Combining_Algorithm = PolicySet_Evaluation ($Policy_stack,$Request_stack);

//echo "<pre>";
//var_dump($_Combining_Algorithm);
// Call desision making for conflicts
$_Response = Combinig_Algorithm ($_Combining_Algorithm);

if ($_Response[4] == '')
{
	$_Response[4] = 'Indeterminate';
}

// Call Display to display the response on the terminal
Display_Response($_Response);

?>