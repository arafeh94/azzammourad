<?php

/**
 * Build XACML base Policy.
*/


$policy_count = 199;
$rule_count = 139;

$x = $policy_count - 100 + 1;
$y = $rule_count - 100 + 1;
$z = $x*$y;
echo "number of rules = ".$z;
//$number_of_policies_rules = ($policy_count - 100) * (rule_count - 100);

$rule_effect = "Permit";

// display data on screen
function display ($array)
{
	echo "<pre>";
	print_r ($array);
	echo "<pre/>";
}


// Open Policy Set file and load it in an array

$PolicySet_file=fopen('C:\Program Files\EasyPHP-DevServer-14.1VC9\data\localweb\www\oldxacml\xml\PolicySet.xml',"r") or exit("Unable to open PolicySet file for reading!");

$PolicySet_lines = array();

if ($PolicySet_file)
{
   while (!feof($PolicySet_file))
   {
	   $PolicySet_lines[] = fgets($PolicySet_file, 512);
   }
   fclose($PolicySet_file);
}


// Open Policy file and load it in an array

$Policy_file=fopen('C:\Program Files\EasyPHP-DevServer-14.1VC9\data\localweb\www\oldxacml\xml\Policy.xml',"r") or exit("Unable to open Policy file for reading!");

$Policy_lines = array();

if ($Policy_file)
{
   while (!feof($Policy_file))
   {
	   $Policy_lines[] = fgets($Policy_file, 512);
   }
   fclose($Policy_file);
}


// Open Policy file and load it in an array

$Rule_file=fopen('C:\Program Files\EasyPHP-DevServer-14.1VC9\data\localweb\www\oldxacml\xml\Rule.xml',"r") or exit("Unable to open Rule file for reading!");

$Rule_lines = array();

if ($Rule_file)
{
   while (!feof($Rule_file))
   {
	   $Rule_lines[] = fgets($Rule_file, 512);
   }
   fclose($Rule_file);
}

// Open BasePolicy File for writting

$BasePolicy_file=fopen($z.'.xml',"w") or exit("Unable to open BasePolicy file for writting!");

// load Policy Set portion at the begining of the BasePolicy File

$XML_lines = 0;
for ($count = 0;$count< count($PolicySet_lines);$count++)
{
	$XML[$XML_lines] = $PolicySet_lines[$count];
/*	if ($count == 0)
	{
		$XML[$XML_lines] = str_replace ('POLICY','Policy'.$policy,$Policy_lines[$count]);
	}
*/
	$xml = $XML[$XML_lines];
	fwrite ($BasePolicy_file, $xml);
	$XML_lines++;
}

// Loop through the polices

for ($policy = 100;$policy <= $policy_count;$policy++)
{
	// append the policy to the basepolicy file

	for ($count = 0;$count< count($Policy_lines);$count++)
	{
		if ($count == 0)
		{
			$XML[$XML_lines] = str_replace ('POLICY','P'.$policy,$Policy_lines[$count]);
		}
		else
		{
			$XML[$XML_lines] = $Policy_lines[$count];
		}

		$xml = $XML[$XML_lines];
		fwrite ($BasePolicy_file, $xml);
		$XML_lines++;

	}



	for ($rule = 100;$rule <= $rule_count;$rule++)
	{
		for ($count = 0;$count< count($Rule_lines);$count++)
		{
			if ($count == 0)
			{
//				$XML[$XML_lines] = str_replace ('EFFECT',$rule_effect,$Rule_lines[$count]);
				$XML[$XML_lines] = str_replace ('RULE','R'.$policy.".".$rule,$Rule_lines[$count]);
			}
			else
			{
				$XML[$XML_lines] = $Rule_lines[$count];
			}

			$xml = $XML[$XML_lines];
			fwrite ($BasePolicy_file, $xml);
			$XML_lines++;
		}
	}
	// Close Policy XML Tag

	$XML[$XML_lines] = "</Policy>"."\n";
	$xml = $XML[$XML_lines];
	fwrite ($BasePolicy_file, $xml);
	$XML_lines++;

}

// Close PolicySet XML Tag
$XML_lines++;
$XML[$XML_lines] = "</PolicySet>";
$xml = $XML[$XML_lines];
fwrite ($BasePolicy_file, $xml);
?>