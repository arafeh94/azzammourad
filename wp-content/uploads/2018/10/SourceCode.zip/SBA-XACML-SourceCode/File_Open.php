<?php

/**
 * File open procedure
*/
function file_open($file_name)
{
	$x = 8192;
	$lines = array();
	$handle = @fopen($file_name, "r");
	if ($handle)
	{
	   while (!feof($handle))
	   {
			$lines[] = fgets($handle, $x);
	   }
	   fclose($handle);
	}
	return $lines;
}
?>