<?php

/**
 * load lines procedure
*/
// load the policy into the main array
function load ($lines)
{
	$stack = array();
	foreach($lines as $key0 => $value)
	{
		// explode string to get whether PS,P or R
		$value = str_replace(' ','', $value);
		$explode_line[$key0] = explode('<',$value);

		//get a string count
		$line_count = strlen($explode_line[$key0][1]);
		$loop_counter = 0;
		$count_opened_curly = 0;
		$count_closed_curly = 0;
		$hold_string = '';

		// initialize $stack with policy/rule name
		$stack[$key0] = array($explode_line[$key0][0]);

		while ($loop_counter < $line_count )
		{
			$char = substr($explode_line[$key0][1],$loop_counter,1);
			if( $char == '}')
			{
				$count_closed_curly++;
				$hold_string = $hold_string.$char;
				if ($count_opened_curly == $count_closed_curly)
				{
					array_push($stack[$key0],$hold_string);
					$count_opened_curly = 0;
					$count_closed_curly = 0;
					$hold_string = '';
				}

			}
			else
			{
				if( $char == '{')
				{
					$count_opened_curly++;
				}

				$hold_string = $hold_string.$char;
				// if we get a comma as the first character then we can remove
				if ($hold_string == ',')
				{
					$hold_string = '';
				}
			}

			$loop_counter++;
		}
	}
	return $stack;
}
?>