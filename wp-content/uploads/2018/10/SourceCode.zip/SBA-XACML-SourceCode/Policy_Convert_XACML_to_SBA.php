<?php

/**
 * XA Converts the XACML base Policy to SBA-XACML.
*/

$output_file=fopen('SBA\SBA_Policy.txt',"w") or exit("Unable to open file for writting!");
require("xml2array.php");

function array_values_recursive( $array )
{
    $array = array_values( $array );
    for ( $i = 0, $n = count( $array ); $i < $n; $i++ )
    {
        $element = $array[$i];
        if ( is_array( $element ) )
        {
            $array[$i] = array_values_recursive( $element );
        }
    }
    return $array;
}

function display ($array)
{
	echo "<pre>";
	print_r ($array);
	echo "<pre/>";
}

function target_XA ($array)
{
	$subjects[0] = "";
	$resources[0] = "";
	$actions[0] = "";
	while (key($array))
	{
		// Subjects
		if (key($array) == 'Subjects')
		{
			$Subjects = $array['Subjects'];
			$subjects = subjects ($Subjects);

		}

		// Resources
		if (key($array) == 'Resources')
		{
			$Resources = $array['Resources'];
			$resources = resources ($Resources);
		}

		//
		if (key($array) == 'Actions')
		{
			$Actions = $array['Actions'];
			$actions = actions ($Actions);
		}

		next ($array);
	}
	// need to setup the target
	if (empty($subjects[0]))
	{
		$subjects[0] = "{}";
	}
	if (empty($resources[0]))
	{
		$resources[0] = "{}";
	}
	if (empty($actions[0]))
	{
		$actions[0] = "{}";
	}

	$target[0] = "{".$subjects[0].",".$resources[0].",".$actions[0]."}";
	return $target;
}

function subjects ($array)
{
	$subjects[0] = "";
	if (empty($array))
	{
			$subjects[0] = "{"."}";
			return $subjects;
	}
	if (key($array))
	{
		if (key($array) == 'AnySubject')
		{
			$subjects[0] = "Any";
		}
		else
		{
			// get the number of defined subjects -- count of Subjects
			$S_count = count($array[key($array)]);
			if ($S_count <= 1)
			{
				if (isset($array['Subject']['SubjectMatch']['AttributeValue']['value']))
				{
					$subjects[0] = $array['Subject']['SubjectMatch']['AttributeValue']['value'];
				}
			}
			else
			{
				for ($_index = 0;$_index < $S_count ;$_index++)
				{
					if (isset($array[key($array)]))
					{
						if ($_index == 0)
						{
							$subjects[0] = $array['Subject'][$_index]['SubjectMatch']['AttributeValue']['value'];
						}
						else
						{
							$subjects[0] = $subjects [0].",".$array['Subject'][$_index]['SubjectMatch']['AttributeValue']['value'];
						}
					}
				}
			}
		}

	}
	$subjects[0] = "{".$subjects[0]."}";
	return $subjects;
}

// parse the resources att.
function resources ($array)
{
	$resources[0] = "";
	if (empty($array))
	{
		$resources[0] = "{"."}";
		return $resources;
	}

	if (key($array))
	{
		if (key($array) == 'AnyResource')
		{
			$resources[0] = "Any";
		}
		else
		{
			// get the number of defined resources -- count of Resources
			$R_count = count($array[key($array)]);
			if ($R_count <= 1)
			{
				if (isset($array['Resource']['ResourceMatch'][0]))
				{
					$RM_count = count ($array['Resource']['ResourceMatch']);
					//var_dump($array['Resource']['ResourceMatch']);
					for ($_RM_count = 0; $_RM_count < $RM_count; $_RM_count++)
					{
						if ($_RM_count == 1)
						{
							$resources[0] = $array['Resource']['ResourceMatch'][$_RM_count]['AttributeValue']['value'];
						}
						else
						{
							$resources[0] = $resources[0].",".$array['Resource']['ResourceMatch'][$_RM_count]['AttributeValue']['value'];
						}
					}
				}
				else
				{
					$resources[0] = $array['Resource']['ResourceMatch']['AttributeValue']['value'];
				}
			}
			else
			{
				for ($_index = 0;$_index < count($array[key($array)]);$_index++)
				{
					if (isset($array[key($array)]))
					{
						if ($_index == 0)
						{
							$resources[0] = $array['Resource'][$_index]['ResourceMatch']['AttributeValue']['value'];
						}
						else
						{
							$resources[0] = $resources[0].",".$array['Resource'][$_index]['ResourceMatch']['AttributeValue']['value'];
						}
					}
				}
			}
		}

	}
	$resources[0] = "{".$resources[0]."}";
	return $resources;
}

// parse the actions att.
function actions ($array)
{
	$actions[0] = "";
	if (key($array))
	{
		if (key($array) == 'AnyAction')
		{
			$actions[0] = "Any";
		}
		else
		{
			// get the number of defined actionss -- count of actions
			$A_count = count($array[key($array)]);
			if ($A_count <= 1)
			{
				$actions[0] = $array['Action']['ActionMatch']['AttributeValue']['value'];
			}
			else
			{
				for ($_index = 0;$_index < count($array[key($array)]);$_index++)
				{
					if (isset($array[key($array)]))
					{
						if ($_index == 0)
						{
							$actions[0] = $array['Action'][$_index]['ActionMatch']['AttributeValue']['value'];
						}
						else
						{
							$actions[0] = $actions[0].",".$array['Action'][$_index]['ActionMatch']['AttributeValue']['value'];
						}

					}
				}
			}
		}

	}
	$actions[0] = "{".$actions[0]."}";
	return $actions;
}


// parse the Obligations
function obligations($array)
{
	$number_of_obligations = 1;
	$x = "";
	$y = "";
	$z = "";
	$obligation_array = array();
	$index_obl = 0;
	// if one obligation
	if (key ($array['Obligation']))
	{
		$obligations[0] = obligation_XA($array['Obligation']);
	}
	else // Multiple Obligations
	{
		$number_of_obligations = count ($array['Obligation']);
		for ($_obligation = 0; $_obligation < $number_of_obligations; $_obligation++)
		{
			$obligations[$_obligation] = obligation_XA($array['Obligation'][$_obligation]);
		}
	}
	for ($_obligations = 0; $_obligations < $number_of_obligations; $_obligations++)
	{
		$z = "";
		if ($obligations[$_obligations][0][0])
		{
			$x = $obligations[$_obligations][0][0];
		}
		if ($obligations[$_obligations][0][1])
		{
			$x = $x.",".$obligations[$_obligations][0][1];
		}

 		$number_of_obligation = count ($obligations[$_obligations]);
 		for ($_obligation = 1; $_obligation < $number_of_obligation; $_obligation++)
		{
			$y = "";
			if ($obligations[$_obligations][$_obligation][0])
			{
				$att_id = explode(":",$obligations[$_obligations][$_obligation][0]);
				$number_of_arrays_in_att_id = count($att_id);
				$y = "{".$att_id[$number_of_arrays_in_att_id - 3].":".$att_id[$number_of_arrays_in_att_id - 2].":".$att_id[$number_of_arrays_in_att_id - 1];
			}
			else
			{
				$y = "{".$y;
			}
			// Data type at the obl. level
			if ($obligations[$_obligations][$_obligation][1])
			{
				$data_type = explode("#",$obligations[$_obligations][$_obligation][1]);
				$number_of_arrays = count($data_type);
				$y = $y.",".$data_type[$number_of_arrays - 1];
			}
			else
			{
				$y = $y.",";
			}
			// Value at the obl. level
			if ($obligations[$_obligations][$_obligation][2])
			{
				$y = $y.",".$obligations[$_obligations][$_obligation][2]."}";
			}
			else
			{
				$y = $y;
			}
			$z = $z.",".$y;
		}
		$obligation_array[$index_obl] = $x.$z;
		$index_obl++;

	}
	$number_obligation_array = count($obligation_array);
	$obligation_string = "";
	if ($number_obligation_array == 1)
	{
		$obligation_string = $obligation_array[0];
		return $obligation_string;
	}
	for ($count = 0; $count < $number_obligation_array;$count++)
	{
		$obligation_string = $obligation_string."{".$obligation_array[$count];
		$obligation_string = $obligation_string."}";
		if ($count < ($number_obligation_array - 1))
		{
			$obligation_string = $obligation_string.",";
		}
	}
	return $obligation_string;
}

// parse the Obligation
function obligation_XA($array)
{
	while (key($array))
	{
		// if attr
		if (key($array) == 'attr')
		{
			while (key($array[key($array)]))
			{
				if (key($array[key($array)]) == 'FulfillOn')
				{
					$Obligation[0][0] = $array[key($array)]['FulfillOn'];
				}
				if (key($array[key($array)]) == 'ObligationId')
				{
					$Obligation[0][1] = $array[key($array)]['ObligationId'];
				}
				next ($array[key($array)]);
			}
		}

		// if AttributeAssignment
		if (key($array) == 'AttributeAssignment')
		{
			if (key($array['AttributeAssignment']))
			{
				while (key($array['AttributeAssignment']))
				{
					if (key($array[key($array)]) == 'value')
					{
						$Obligation[1][2] = $array[key($array)]['value'];
					}
					if (key($array[key($array)]) == 'attr')
					{
						while(key($array['AttributeAssignment']['attr']))
						{
							if (key($array['AttributeAssignment']['attr']) == 'AttributeId')
							{
								$Obligation[1][0] = $array[key($array)]['attr']['AttributeId'];
							}
							if (key($array['AttributeAssignment']['attr']) == 'DataType')
							{
								$Obligation[1][1] = $array[key($array)]['attr']['DataType'];
							}
							next ($array['AttributeAssignment']['attr']);
						}
					}
					next ($array['AttributeAssignment']);
				}
			}
			else	// get the number of att. assignments
			{
				$number_of_att_assignments = count($array['AttributeAssignment']);
				for ($_att_assign = 0; $_att_assign < $number_of_att_assignments;$_att_assign++)
				{
					while (key($array['AttributeAssignment'][$_att_assign]))
					{
						if (key($array[key($array)][$_att_assign]) == 'value')
						{
							$Obligation[$_att_assign + 1][2] = $array[key($array)][$_att_assign]['value'];
						}
						if (key($array[key($array)][$_att_assign]) == 'attr')
						{
							while(key($array['AttributeAssignment'][$_att_assign]['attr']))
							{
								if (key($array['AttributeAssignment'][$_att_assign]['attr']) == 'AttributeId')
								{
									$Obligation[$_att_assign + 1][0] = $array[key($array)][$_att_assign]['attr']['AttributeId'];
								}
								if (key($array['AttributeAssignment'][$_att_assign]['attr']) == 'DataType')
								{
									$Obligation[$_att_assign + 1][1] = $array[key($array)][$_att_assign]['attr']['DataType'];
								}
								next ($array['AttributeAssignment'][$_att_assign]['attr']);
							}
						}
						next ($array['AttributeAssignment'][$_att_assign]);
					}
				}


			}
		}

		next ($array);
	}
	return $Obligation;
}

// parses the attr at the PolicySet level -- parses the PCA and PolicySet Name
function PolicySet_attr ($array)
{
	while (isset($array[key($array)]))
	{
		if(key($array) == 'PolicyCombiningAlgId')
		{
			$temp[0] = $array[key($array)];
			$temp[0] = explode(":",$temp[0]);
			$PolicySet_attr[0][1] = $temp[0][7];
		}
		if(key($array) == 'PolicySetId')
		{
			$PolicySet_attr[0][0] = $array[key($array)];
		}

		next ($array);
	}
	return $PolicySet_attr;
}


// parses the attr at the policy level -- parses the RCA and Policy Name
function Policy_attr ($array)
{
	while (isset($array[key($array)]))
	{
		if(key($array) == 'RuleCombiningAlgId')
		{
			$temp[0] = $array[key($array)];
			$temp[0] = explode(":",$temp[0]);
			$Policy_attr[0][1] = $temp[0][7];

		}
		if(key($array) == 'PolicyId')
		{
			$Policy_attr[0][0] = $array[key($array)];
		}

		next ($array);
	}

	return $Policy_attr;
}



// Policy parser -- takes a Policy and the Policy may contain Rules
function policy ($policy)
{
	while (key($policy))
	{
		// Parse attributes
		if (key($policy) == 'attr')
		{
			$attr = ($policy[key($policy)]);
			$ret_call_result = Policy_attr($attr);
			$_Policy[0] = $ret_call_result[0];
		}
		// Parse Target
		if (key($policy) == 'Target')
		{

			$Target = ($policy[key($policy)]);
			if (empty ($Target))
			{
				$target[0][0] = "{{},{},{}}";
			}
			else
			{
				$target [0] = target_XA ($Target);
			}
			$_Policy[0][2] = $target[0][0];
		}
		// parse Obligation at the Policy Level
		if (key($policy) == 'Obligations')
		{
			$obligation = obligations($policy[key($policy)]);
			$_Policy[0][6] = $obligation;
		}

		// Parse Rules
		if (key($policy) == 'Rule')
		{
			if (isset ($policy[key($policy)]))
			{
				$Rule = ($policy[key($policy)]);
				if (key($Rule))
				{
					while (key($policy[key($policy)]))
					{
						// attr at the rule level
						if (key($policy[key($policy)]) == 'attr')
						{
							$Rule_ID[0] = $policy[key($policy)]['attr']['RuleId'];
							$_Policy[1][0][0] = $Rule_ID[0];
							$Rule_effect[0] = $policy[key($policy)]['attr']['Effect'];
							$_Policy[1][0][1] = $Rule_effect[0];
						}

						// Target at the rule level
						if (key($policy[key($policy)]) == 'Target')
						{
							$Target = $policy[key($policy)]['Target'];
							if (empty($Target))
							{
								$target[0] = "{{},{},{}}";
							}
							else
							{
								$temp = "";
								$temp = target_XA($Target);
								$target[0] = $temp[0];
								$temp = "";
							}
							$_Policy[1][0][2] = $target[0];
						}

						// Condition at the rule level
						if (key($policy[key($policy)]) == 'Condition')
						{
							$_Policy[1][0][3] = 'RC';
						}
						$_Policy[1][0][4] = "R";

						next ($policy[key($policy)]);
					}// end of while loop

				}
				else
				{
					$_Number_of_rules = count ($policy[key($policy)]);
					for ($_index = 0; $_index < $_Number_of_rules;$_index++)
					{
						while (key($policy[key($policy)][$_index]))
						{
							// attr at the rule level
							if (key($policy[key($policy)][$_index]) == 'attr')
							{
								$Rule_ID[$_index] = $policy[key($policy)][$_index]['attr']['RuleId'];
								$_Policy[1][$_index][0] = $Rule_ID[$_index];
								if (key($policy[key($policy)][$_index]['attr']) == 'Effect')
								{
									$Rule_effect[$_index] = $policy[key($policy)][$_index]['attr']['Effect'];
									$_Policy[1][$_index][1] = $Rule_effect[$_index];

								}
							}
							// Target at the rule level
							if (key($policy[key($policy)][$_index]) == 'Target')
							{
								$Target = $policy[key($policy)][$_index]['Target'];
								if (empty($Target))
								{
									$target[$_index] = "{{},{},{}}";
								}
								else
								{
									$temp = "";
									$temp[$_index] = target_XA($Target);
									$target[$_index] = $temp[$_index];
									$temp = "";
								}
								$_Policy[1][$_index][2] = $target[$_index];

							}

							// Condition at the rule level
							if (key($policy[key($policy)][$_index]) == 'Condition')
							{
								$_Policy[1][$_index][3] = 'RC.$_index';
								//echo key ($policy[key($policy)][$_index]);
							}
							$_Policy[1][$_index][4] = "R";
							next ($policy[key($policy)][$_index]);
						}// end of while loop

					} // end of for loop
				}
			}
		}

		// Parse Obligations
		if (key($policy) == 'Obligations')
		{
			$Obligations = ($policy[key($policy)]);
			//Obligation ($Obligations);
		}

		next($policy);
	}
	return $_Policy;
}



$contents = file_get_contents('XACML\XACML_Policy.xml');
$result = xml2array($contents);
while (key($result))
{
	// children level 1
	if (isset($result[key($result)]))
	{
		while (key($result[key($result)]))
		{
			// Parse attributes at the PS level
			if (key ($result[key($result)]) == 'attr')
			{
				$attr = ($result[key($result)]['attr']);
				$ret_call_result = PolicySet_attr($attr);
				$PS[0] = $ret_call_result[0];
			}

			// Parse Target
			if (key ($result[key($result)]) == 'Target')
			{
				$Target = ($result[key($result)]['Target']);
				$target = target_XA ($Target);
				$PS[0][2] = $target[0];
				$PS[0][3] = "";
				$PS[0][4] = "";
				$PS[0][5] = "PS";

			}

			// Parse Policy
			if (key ($result[key($result)]) == 'Policy')
			{
				$Policy = ($result[key($result)]['Policy']);

				// if one Policy
				if (key($Policy))
				{
					$policy = policy($Policy);
					$policy[0][3] = "";
					$policy[0][4] = "";
					$policy[0][5] = "P";
					$PS[1] = $policy;
 				}
 				else
 				{
 					$array_index = 1;
 					$_Number_of_Policies = count($Policy);
 					for ($_policy = 0;$_policy < $_Number_of_Policies; $_policy++)
 					{
 						$policy = policy($Policy[$_policy]);
 						$policy[0][3] = "";
 						$policy[0][4] = "";
 						$policy[0][5] = "P";
 						$PS[$array_index] = $policy;
 						$array_index++;
					}
				}
			}
			// if Obligations
			if ( key ($result[key($result)]) == 'Obligations')
			{
				$obligation = obligations($result[key($result)][key ($result[key($result)])]);
				$PS[0][6] = $obligation;
			}
			next ($result[key($result)]);
		}
	}
	next($result);
}

// combing the policies to the PolicySet and the rules to the Policies
$number_of_policies = count($PS);

for ($_loop = 1; $_loop < $number_of_policies;$_loop++)
{
		if (empty($PS[0][3]))
		{
			$PS[0][3] = $PS[$_loop][0][0];
			if ($number_of_policies > 1)
			{
				$PS[0][4] = $PS[$_loop][0][0];
			}
		}
		else
		{
			$PS[0][3] = $PS[0][3].",".$PS[$_loop][0][0];
			if ($number_of_policies > 1)
			{
				$PS[0][4] = $PS[0][4].">".$PS[$_loop][0][0];
			}
		}

		$number_of_rules = count ($PS[$_loop][1]);
		for ($_loop2 = 0; $_loop2 < $number_of_rules ;$_loop2++)
		{
			if(isset ($PS[$_loop][1][$_loop2]))
			{
				if (empty($PS[$_loop][0][3]))
				{
					$PS[$_loop][0][3] = $PS[$_loop][1][$_loop2][0];
					if ($number_of_rules > 1)
					{
						$PS[$_loop][0][4] = $PS[$_loop][1][$_loop2][0];
					}
				}
				else
				{
					$PS[$_loop][0][3] = $PS[$_loop][0][3].",".$PS[$_loop][1][$_loop2][0];
					if ($number_of_rules > 1)
					{
						$PS[$_loop][0][4] = $PS[$_loop][0][4].">".$PS[$_loop][1][$_loop2][0];
					}
				}
			}
			else
			{
			}
		}
}

//display ($PS);
// format the SBA tyle now
$number_of_policies = count($PS);
$_line = -1;
for ($_loop = 0; $_loop < $number_of_policies;$_loop++)
{
	$_line++;
	if ($_loop == 0)
	{
		if ($PS[0][5] == 'PS')
		{
			if (empty ($PS[0][5]))
			{
				$PS[0][7]= "";
			}
			if (empty ($PS[0][7]))
			{
				$PS[0][7]= "";
			}
			if (empty ($PS[0][6]))
			{
				$PS[0][6]= "";
			}

			$XA[$_line] = $PS[$_loop][5]."::=<".$PS[$_loop][0].",{".$PS[$_loop][3]."},{".$PS[$_loop][4]."},{".$PS[$_loop][1]."},{".$PS[$_loop][7]."},{".$PS[$_loop][6]."},".$PS[$_loop][2].">\r\n";
			$xa = $XA[$_line];
			fwrite ($output_file, $xa);
		}
	}
	else // index of first array > 0
	{
		$number_of_rules = count($PS[$_loop][1]);
		for ($_loop2 = 0; $_loop2 <  2 ;$_loop2++)
		{
			if ($_loop2 == 0)
			{
				//display($PS[$_loop][$_loop2]);
				if ($PS[$_loop][$_loop2][5] == 'P')
				{
					if (!isset ($PS[$_loop][$_loop2][1]))
					{
						$PS[$_loop][$_loop2][1] = "";
					}
					if (!isset ($PS[$_loop][$_loop2][6]))
					{
						$PS[$_loop][$_loop2][6] = "";
					}

					$_line++;
					$XA[$_line] = $PS[$_loop][$_loop2][5]."::=<".$PS[$_loop][$_loop2][0].",{".$PS[$_loop][$_loop2][3]."},{".$PS[$_loop][$_loop2][4]."},{".$PS[$_loop][$_loop2][1]."},{".$PS[$_loop][$_loop2][6]."},".$PS[$_loop][$_loop2][2].">\r\n";
					$xa = $XA[$_line];
					fwrite ($output_file, $xa);

				}
			}
			else	// index of second array > 0 so we are getting to rules
			{

				for ($_loop3 = 0; $_loop3 <  $number_of_rules ;$_loop3++)
				{
					// if no data in the array elements lood with null
					if (!isset ($PS[$_loop][$_loop2][$_loop3][0]))
					{
						$PS[$_loop][$_loop2][$_loop3][0] = "";
					}

					if (!isset ($PS[$_loop][$_loop2][$_loop3][1]))
					{
						$PS[$_loop][$_loop2][$_loop3][1] = "";
					}
					if (!isset ($PS[$_loop][$_loop2][$_loop3][2]))
					{
						$PS[$_loop][$_loop2][$_loop3][2] = "";
					}
					if (!isset ($PS[$_loop][$_loop2][$_loop3][3]))
					{
						$PS[$_loop][$_loop2][$_loop3][3] = "";
					}
					if (!isset ($PS[$_loop][$_loop2][$_loop3][4]))
					{
						$PS[$_loop][$_loop2][$_loop3][4] = "";
					}

			    	$_line++;
					if (($_loop == ($number_of_policies - 1)) && ($_loop2 == 1) && ($_loop3 == ($number_of_rules - 1)))
					{
						if ($PS[$_loop][$_loop2][$_loop3][2][0] == '{')
						{
							$XA[$_line] = $PS[$_loop][$_loop2][$_loop3][4]."::=<".$PS[$_loop][$_loop2][$_loop3][0].",{".$PS[$_loop][$_loop2][$_loop3][3]."},".$PS[$_loop][$_loop2][$_loop3][2].",{".$PS[$_loop][$_loop2][$_loop3][1]."}".">";
						}
						else
						{
							$XA[$_line] = $PS[$_loop][$_loop2][$_loop3][4]."::=<".$PS[$_loop][$_loop2][$_loop3][0].",{".$PS[$_loop][$_loop2][$_loop3][3]."},".$PS[$_loop][$_loop2][$_loop3][2][0].",{".$PS[$_loop][$_loop2][$_loop3][1]."}".">";
						}
						$xa = $XA[$_line];
						fwrite ($output_file, $xa);

					}
					else
					{
						if ($PS[$_loop][$_loop2][$_loop3][2][0] == '{')
						{
							//var_dump ($PS[$_loop][$_loop2][$_loop3][2]);
							$XA[$_line] = $PS[$_loop][$_loop2][$_loop3][4]."::=<".$PS[$_loop][$_loop2][$_loop3][0].",{".$PS[$_loop][$_loop2][$_loop3][3]."},".$PS[$_loop][$_loop2][$_loop3][2].",{".$PS[$_loop][$_loop2][$_loop3][1]."}".">"."\n";
						}
						else
						{
							// if warnning remove 0
							$XA[$_line] = $PS[$_loop][$_loop2][$_loop3][4]."::=<".$PS[$_loop][$_loop2][$_loop3][0].",{".$PS[$_loop][$_loop2][$_loop3][3]."},".$PS[$_loop][$_loop2][$_loop3][2][0].",{".$PS[$_loop][$_loop2][$_loop3][1]."}".">"."\n";
						}
						$xa = $XA[$_line];
						fwrite ($output_file, $xa);
					}
				}

			}
			$_line++;

		}
	}

}
fclose($output_file);

?>